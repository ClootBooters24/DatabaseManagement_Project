#!/bin/bash
set -e -v

#./clear.sh

javac *.java